(function() {
  Actions.init();
  Status.init();
  Snippets.init();
})();
