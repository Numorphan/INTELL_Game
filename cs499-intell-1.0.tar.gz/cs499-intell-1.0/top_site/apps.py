from django.apps import AppConfig


class TopSiteConfig(AppConfig):
    name = 'top_site'
