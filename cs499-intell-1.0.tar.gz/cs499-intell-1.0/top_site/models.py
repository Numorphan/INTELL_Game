'''
    INTELL The Craft of Intelligence
        https://github.com/dylan-wright/cs499-intell/
        https://intellproject.com

        /top_site/models.py
            Django models
'''
from django.db import models

# Create your models here.
